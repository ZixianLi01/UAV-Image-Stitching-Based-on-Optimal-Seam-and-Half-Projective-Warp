%%
close all;
clear;
%change your path
fold='F:\ͼ��ƴ��\code\RS';

%image fold
%need source images 'p1.jpg' 'p2.jpg'  and registered images 'p_01.png' 'p_02.png'
image_fold='images';

half=1; %use half projective

%optimal seam
Seam_method;

%half_projective
if half==1
Half_projective;
end