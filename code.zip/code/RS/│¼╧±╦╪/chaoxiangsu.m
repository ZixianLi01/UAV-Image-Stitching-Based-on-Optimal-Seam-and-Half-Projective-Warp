function cxs_mask=chaoxiangsu(X)
    niv_gris=16;
    im_gris=rgb2gray(X);
    [X_gris,X_coo]=niveaux_gris2(X,niv_gris,im_gris);

    % Transforming the image into its texture features
    N=300;
    im_param = diviserParam(X, niv_gris, N);

    % Dividing the image into superpixels using the SLIC algorithm
    t=[0 10];
    M=mat_coocurrence(X_coo,t,niv_gris);
    [l, Am, Sp] = slic(X, im_param, N, 30, 1, 'median');
    h = [-1 1];  % A simple small filter is better in this application.
                 % Small regions 1 pixel wide get missed using a Sobel
                 % operator 
    gx = filter2(h ,l);
    gy = filter2(h',l);
    maskim = (gx.^2 + gy.^2) > 0;
    maskim = bwmorph(maskim, 'thin', Inf);
    
    % Zero out any mask values that may have been set around the edge of the
    % image.
    maskim(1,:) = 0; maskim(end,:) = 0;
    maskim(:,1) = 0; maskim(:,end) = 0;
    cxs_mask=maskim;
end