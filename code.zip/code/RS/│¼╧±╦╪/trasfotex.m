%% conversion en fichier .tex

a = m2tex('testdbscan.m')