%%
function [mask1, mask2, mask22,seam,pseam,allseam]=SeamEstimationb(img1, img2, mask1, mask2)


ms1=mask1;
ms2=mask2;
   
%% find start & end points to search a seam & select public region
 [points,im1,im2,mask,Dx,Dy,~,twop]=FindStEnPintsAndRegion(img1,img2,mask1,mask2);   
% points  ͼ���ص����ֵ������յ�
% im1 & im2 ͼ��1ͼ��2�Ķ�Ӧ�ص�����
% mask ͼ���ص���������
% Dx & Dy ͼ���ص����ֲü�����XY����
% twop ͼ���ص����������յ�����
%%    
    ColDif=abs(im2double(im1)-im2double(im2)); %��ͼ���
    m=min(ColDif,[],3);  % ����ά����ÿ��λ����Сֵ
    s=((sum(ColDif,3)-m)/2);  %��ά��������ȥ��Сֵ�ٳ���
    ColDif=ColDif.*repmat(double(mask),[1,1,3]);  %ȥ�����ظ�����
    a=(mean(max(ColDif,[],1))+mean(min(ColDif,[],1)))/2; %ÿ�����ֵ����Сֵ��ӳ�2
    b=(mean(max(ColDif,[],2))+mean(min(ColDif,[],2)))/2; %ÿ�����ֵ����Сֵ��ӳ�2
    max_=(a+b)/2;  %�ظ�����ÿ��ͼ����ɫ��ֵ
    color_mask=[];
    color_mask(:,:,1)= ColDif(:,:,1) - max_(1,1,1); %�ظ������ȥͼ����ɫ��ֵ
    color_mask(:,:,2)= ColDif(:,:,2) - max_(1,1,2);
    color_mask(:,:,3)= ColDif(:,:,3) - max_(1,1,3);
    color_mask(color_mask<0)=0;   %��ɫ����
    
    [msk,~]=ImgClassification2(im1,im2,color_mask,mask,points,s,twop);


    seam=zeros(size(ms1));
    seam(Dy+1:size(msk,1)+Dy,Dx+1:size(msk,2)+Dx)=msk;
    %
    seampoint1=points(:,:,1);
    seampoint2=points(:,:,2);
    seampoint=seampoint1+seampoint2;
    
    seampoints=zeros(size(ms1));
    seampoints1=zeros(size(ms1));
    seampoints2=zeros(size(ms1));
    
    seampoints(Dy+1:size(msk,1)+Dy,Dx+1:size(msk,2)+Dx)=seampoint;
    seampoints1(Dy+1:size(msk,1)+Dy,Dx+1:size(msk,2)+Dx)=seampoint1;
    seampoints2(Dy+1:size(msk,1)+Dy,Dx+1:size(msk,2)+Dx)=seampoint2;
    
    seampoints1=seampoints1*255;
    seampoints2=seampoints2*255;
    imwrite(seampoints1,'F:\ͼ��ƴ��\SPHP\SPHP_Image_Stitching-master\images\seampoints1.png');
    imwrite(seampoints2,'F:\ͼ��ƴ��\SPHP\SPHP_Image_Stitching-master\images\seampoints2.png');
    
    [seamstartX,seamstartY]=find(seampoints~=0);
    save('F:\ͼ��ƴ��\SPHP\SPHP_Image_Stitching-master\seamstart.mat','seamstartX','seamstartY');
    %
    seam=bwmorph(seam,'diag');
    seam=imfill(uint8(seam));
    
    mask1=ms1-seam;
    cc1=bwlabel(mask1);
    
    mask2=(ms2)-uint8(seam);
    cc2=bwlabel(mask2);
    
    m1=double(mask1-mask2).*cc1;
    m2=double(mask2-mask1).*cc2;

    u1=unique(m1);
    u2=unique(m2);
    
    mask1=zeros(size(mask1));
    mask2=zeros(size(mask2));
    
    mask1(cc1==u1(2))=1;
    mask2(cc2==u2(end))=1;
    mask1=mask1+double(seam);
    mask22=mask2+double(seam);
    % �Ľ�
    pseam=bwmorph(mask1,'remove');
    tp=rgb2gray(img1)&rgb2gray(img1);
    tp=bwmorph(tp,'remove');
    pseam=xor(pseam,tp);
    pseam=pseam-tp;
    %%%%
    mas1=bwmorph(ms1,'remove');
    mas2=bwmorph(ms2,'remove');
    allseam=0;
    %%%%
%     seam=pseam;
    %%%%%%%%%%%%
    
%     imshow(seam);
%     ttseam=seam;
%     ttseam=bwmorph(ttseam,'remove');
%     for i=1:DD.NumObjects
%         ttseam(DD.PixelIdxList{1,i}(1))=0;
%     end
%     TT=bwconncomp(ttseam);
%     if TT.NumObjects~=1
%         tseam=zeros(size(seam));
%         tseam(TT.PixelIdxList{1,1})=1;
%         for i=1:DD.NumObjects
%             ttseam(DD.PixelIdxList{1,i}(1))=1;
%         end
%         seam=tseam;
%     else
%         seam2=bwmorph(seam,'skel',Inf);
%         seam1=bwmorph(seam,'skel',Inf);
%         for i=1:DD.NumObjects
%             seam1(DD.PixelIdxList{1,i}(1))=1;
%         end
%         EE=bwconncomp(seam1);
%         testm=seam1-1;
%         while testm~=seam1
%             for i=1:numel(EE.PixelIdxList{1,1})
%                 testm=seam1;
%                 testseam=seam1;
%                 testseam(EE.PixelIdxList{1,1}(i))=0;
%                 FF=bwconncomp(testseam);
%                 if FF.NumObjects==1
%                     seam1(EE.PixelIdxList{1,1}(i))=0;
%                     continue;
%                 else
%                     for j=1:FF.NumObjects
%                         if ~ismember(DD.PixelIdxList{1,1}(1),FF.PixelIdxList{1,j}) && ~ismember(DD.PixelIdxList{1,2}(1),FF.PixelIdxList{1,j})
%                             seam1(FF.PixelIdxList{1,j})=0;
%                         end
%                     end
%                 end
% 
%             end
%         end
%         for i=1:DD.NumObjects
%             seam1(DD.PixelIdxList{1,i})=1;
%         end
%         seam=seam1;
%     end

    
    
%     pos=EE.PixelIdxList{1,1};
%     for i=1:numel(EE.PixelIdxList{1,1})
%         testseam=seam1;
%         testseam(EE.PixelIdxList{1,1}(i))=0;
%         FF=bwconncomp(testseam);
%         if FF.NumObjects==1
%             seam1(EE.PixelIdxList{1,1}(i))=0;
%             continue;
%         end
%         for j=1:FF.NumObjects
%             if(ismember(DD.PixelIdxList{1,1}(1),FF.PixelIdxList{1,j}) && ismember(DD.PixelIdxList{1,2}(1),FF.PixelIdxList{1,j}))
%             continue;
%             else
%                 seam1(FF.PixelIdxList{1,j})=0;
%             end
%         end
%     end
%     imshow(seam1);
%     for i=1:DD.NumObjects
%         seam(DD.PixelIdxList{1,i})=0;
%     end
%     EE=bwconncomp(seam);
%     tseam=zeros(size(seam));
%     tseam(EE.PixelIdxList{1,1})=1;

    

end