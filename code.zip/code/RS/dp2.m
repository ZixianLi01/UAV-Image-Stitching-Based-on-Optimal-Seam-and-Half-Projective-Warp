%%
%get the optimal seam from energy function, use dp method
%take the minimum total energy seam as the result
%
function seam=dp2(ef,p1,p2,im11,im22)
kk=rgb2gray(im11)&rgb2gray(im22);
kk2=ones(size(rgb2gray(im11)));
kk2=kk2-kk;
kk2(kk2==1)=-1;
kk2(ef==1)=-1;
start=1;
map=ef;
map=map+0.0001;
map(map>1)=1;
map(kk2<0)=50;
[m,n]=size(map);
Infected=[];
Infect=zeros(size(map));
Infect=kk2;
% Infect(map==1)=-1;
kk2(map==1)=-1;
Travers=zeros(size(map));
Infect(p1(1),p1(2))=-1;
Infect(p2(1),p2(2))=0;
Infected=[Infected;p1];
while size(Infected,1)>0
    point=Infected(1,:);
    Travers(point(1),point(2))=-1;
    
    %left
    if point(2)-1>0 && Infect(point(1),point(2)-1)~=-1 && ef(point(1),point(2)-1)>=0
        map(point(1),point(2)-1)=map(point(1),point(2)-1)+minval(map,[point(1),point(2)-1],Infect,kk2);
        Infected=[Infected;[point(1),point(2)-1]];
        Infect(point(1),point(2)-1)=-1;
    end
    %left up
    if point(1)-1>0 && point(2)-1>0 && Infect(point(1)-1,point(2)-1)~=-1 && ef(point(1)-1,point(2)-1)>=0
       map(point(1)-1,point(2)-1)=map(point(1)-1,point(2)-1)+minval(map,[point(1)-1,point(2)-1],Infect,kk2);
       Infected=[Infected;[point(1)-1,point(2)-1]];
       Infect(point(1)-1,point(2)-1)=-1;
    end
    %up
    if point(1)-1>0 && Infect(point(1)-1,point(2))~=-1 && ef(point(1)-1,point(2))>=0
       map(point(1)-1,point(2))=map(point(1)-1,point(2))+minval(map,[point(1)-1,point(2)],Infect,kk2);
       Infected=[Infected;[point(1)-1,point(2)]];
       Infect(point(1)-1,point(2))=-1;
    end
    %right up
    if point(1)-1>0 && point(2)+1<n+1 && Infect(point(1)-1,point(2)+1)~=-1 && ef(point(1)-1,point(2)+1)>=0 
       map(point(1)-1,point(2)+1)=map(point(1)-1,point(2)+1)+minval(map,[point(1)-1,point(2)+1],Infect,kk2);
       Infected=[Infected;[point(1)-1,point(2)+1]];
       Infect(point(1)-1,point(2)+1)=-1;
    end
    %right
    if point(2)+1<n+1 && Infect(point(1),point(2)+1)~=-1 && ef(point(1),point(2)+1)>=0
       map(point(1),point(2)+1)=map(point(1),point(2)+1)+minval(map,[point(1),point(2)+1],Infect,kk2);
       Infected=[Infected;[point(1),point(2)+1]];
       Infect(point(1),point(2)+1)=-1;
    end
    %right dowm
    if point(1)+1<m+1 && point(2)+1<n+1 && Infect(point(1)+1,point(2)+1)~=-1 && ef(point(1)+1,point(2)+1)>=0
       map(point(1)+1,point(2)+1)=map(point(1)+1,point(2)+1)+minval(map,[point(1)+1,point(2)+1],Infect,kk2);
       Infected=[Infected;[point(1)+1,point(2)+1]];
       Infect(point(1)+1,point(2)+1)=-1;
    end
    %down
    if point(1)+1<m+1 && Infect(point(1)+1,point(2))~=-1 && ef(point(1)+1,point(2))>=0
       map(point(1)+1,point(2))=map(point(1)+1,point(2))+minval(map,[point(1)+1,point(2)],Infect,kk2);
       Infected=[Infected;[point(1)+1,point(2)]];
       Infect(point(1)+1,point(2))=-1;
    end
    %left dowm
    if point(1)+1<m+1 && point(2)-1>0 && Infect(point(1)+1,point(2)-1)~=-1 && ef(point(1)+1,point(2)-1)>=0
       map(point(1)+1,point(2)-1)=map(point(1)+1,point(2)-1)+minval(map,[point(1)+1,point(2)-1],Infect,kk2);
       Infected=[Infected;[point(1)+1,point(2)-1]];
       Infect(point(1)+1,point(2)-1)=-1;
    end
    Infected(1,:)=[];
end
nmap=getmap(map,p1,p2,Infect,kk2);
seam=nmap;
end

function newmap=getmap(map,p1,p2,Infect,kk2)
    newmap=zeros(size(map));
    minnum=map(p1(1),p1(2));
    num=map(p2(1),p2(2));
    point=p2;
    newmap(point(1),point(2))=1;
    kk2(point(1),point(2))=-1;
    while num>minnum
        [~,dir]=minval2(map,[point(1),point(2)],kk2);
        switch(dir)
            %left
            case{1}
                point(1)=point(1);
                point(2)=point(2)-1;
            %left up
            case{2}
                point(1)=point(1)-1;
                point(2)=point(2)-1;
            %up
            case{3}
                point(1)=point(1)-1;
                point(2)=point(2);
            %right up
            case{4}
                point(1)=point(1)-1;
                point(2)=point(2)+1;
            %right
            case{5}
                point(1)=point(1);
                point(2)=point(2)+1;
            %right dowm
            case{6}
                point(1)=point(1)+1;
                point(2)=point(2)+1;
            %dowm
            case{7}
                point(1)=point(1)+1;
                point(2)=point(2);
            %left dowm
            case{8}
                point(1)=point(1)+1;
                point(2)=point(2)-1;
        end
        newmap(point(1),point(2))=1;
        kk2(point(1),point(2))=-1;
        num=map(point(1),point(2));
    end
    
end


%get the min infected value of eight directions of current point
function [val,dir]=minval(map,point,Infect,kk2)
[m,n]=size(map);
vals=[];
dirs=[];
%left
if point(2)-1>0 && Infect(point(1),point(2)-1)==-1 && map(point(1),point(2)-1)>=0 && kk2(point(1),point(2)-1)~=-1
    vals=[vals;map(point(1),point(2)-1)];
    dirs=[dirs;1];
end
%left up
if point(1)-1>0 &&point(2)-1>0 && Infect(point(1)-1,point(2)-1)==-1 && map(point(1)-1,point(2)-1)>=0 &&kk2(point(1)-1,point(2)-1)~=-1
   vals=[vals;map(point(1)-1,point(2)-1)]; 
   dirs=[dirs;2];
end
%up
if point(1)-1>0 && Infect(point(1)-1,point(2))==-1 && map(point(1)-1,point(2))>=0 &&kk2(point(1)-1,point(2))~=-1
    vals=[vals;map(point(1)-1,point(2))];
    dirs=[dirs;3];
end
%right up
if point(1)-1>0 && point(2)+1<n+1 && Infect(point(1)-1,point(2)+1)==-1 && map(point(1)-1,point(2)+1)>=0 &&kk2(point(1)-1,point(2)+1)~=-1
   vals=[vals;map(point(1)-1,point(2)+1)]; 
   dirs=[dirs;4];
end
%right
if point(2)+1<n+1 && Infect(point(1),point(2)+1)==-1 && map(point(1),point(2)+1)>=0 && kk2(point(1),point(2)+1)~=-1
   vals=[vals;map(point(1),point(2)+1)]; 
   dirs=[dirs;5];
end
%right dowm
if point(1)+1<m+1 && point(2)+1<n+1 && Infect(point(1)+1,point(2)+1)==-1 && map(point(1)+1,point(2)+1)>=0 && kk2(point(1)+1,point(2)+1)~=-1
   vals=[vals;map(point(1)+1,point(2)+1)]; 
   dirs=[dirs;6];
end
%dowm
if point(1)+1<m+1 && Infect(point(1)+1,point(2))==-1 && map(point(1)+1,point(2))>=0 &&kk2(point(1)+1,point(2))~=-1
   vals=[vals;map(point(1)+1,point(2))]; 
   dirs=[dirs;7];
end
%left dowm
if point(1)+1<m+1 && point(2)-1>0 && Infect(point(1)+1,point(2)-1)==-1 && map(point(1)+1,point(2)-1)>=0 &&kk2(point(1)+1,point(2)-1)~=-1
   vals=[vals;map(point(1)+1,point(2)-1)]; 
   dirs=[dirs;8];
end
[val,n]=min(vals);
dir=dirs(n);
end


%get the min infected value of eight directions of current point
function [val,dir]=minval2(map,point,Infect)
[m,n]=size(map);
vals=[];
dirs=[];
%left
if point(2)-1>0 && Infect(point(1),point(2)-1)~=-1 && map(point(1),point(2)-1)>=0
    vals=[vals;map(point(1),point(2)-1)];
    dirs=[dirs;1];
end
%left up
if point(1)-1>0 &&point(2)-1>0 && Infect(point(1)-1,point(2)-1)~=-1 && map(point(1)-1,point(2)-1)>=0
   vals=[vals;map(point(1)-1,point(2)-1)]; 
   dirs=[dirs;2];
end
%up
if point(1)-1>0 && Infect(point(1)-1,point(2))~=-1 && map(point(1)-1,point(2))>=0
    vals=[vals;map(point(1)-1,point(2))];
    dirs=[dirs;3];
end
%right up
if point(1)-1>0 && point(2)+1<n+1 && Infect(point(1)-1,point(2)+1)~=-1 && map(point(1)-1,point(2)+1)>=0
   vals=[vals;map(point(1)-1,point(2)+1)]; 
   dirs=[dirs;4];
end
%right
if point(2)+1<n+1 && Infect(point(1),point(2)+1)~=-1 && map(point(1),point(2)+1)>=0
   vals=[vals;map(point(1),point(2)+1)]; 
   dirs=[dirs;5];
end
%right dowm
if point(1)+1<m+1 && point(2)+1<n+1 && Infect(point(1)+1,point(2)+1)~=-1 && map(point(1)+1,point(2)+1)>=0
   vals=[vals;map(point(1)+1,point(2)+1)]; 
   dirs=[dirs;6];
end
%dowm
if point(1)+1<m+1 && Infect(point(1)+1,point(2))~=-1 && map(point(1)+1,point(2))>=0
   vals=[vals;map(point(1)+1,point(2))]; 
   dirs=[dirs;7];
end
%left dowm
if point(1)+1<m+1 && point(2)-1>0 && Infect(point(1)+1,point(2)-1)~=-1 && map(point(1)+1,point(2)-1)>=0
   vals=[vals;map(point(1)+1,point(2)-1)]; 
   dirs=[dirs;8];
end
[val,n]=min(vals);
dir=dirs(n);
end
















