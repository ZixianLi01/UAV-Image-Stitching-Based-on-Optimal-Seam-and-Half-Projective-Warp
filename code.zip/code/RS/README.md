# Fast and robust seam estimation
Note: code not optimized
<li>% Matlab code and data to reproduce results from the paper                  %
<li>% "Fast and robust seam estimation to seamless image stitching"             %
<li>% Hadi HejazifarHassan Khotanlou  										                    	%
<li>% available at https://link.springer.com/article/10.1007/s11760-017-1231-3  %
<li>%                                                                           %
<li>% Copyright (C) 2017 Department of Computer Engineering                     %
<li>% Bu-Ali Sina University,                                                   %
<li>% Hamedan, Iran.                                                            %
<li>%                                                                           %
<li>% This program is free code; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free code Foundation; either version 2 of the License, or (at your option) any later version. This code is distributed in the hope that it will be useful, but without any warranty; without even the implied warranty of merchantability or fitness for a particular purpose.
<li>% Latest modifications: June 7, 2017.                                       %
