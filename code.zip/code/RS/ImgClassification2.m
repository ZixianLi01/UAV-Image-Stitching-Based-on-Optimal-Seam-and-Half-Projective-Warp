%%
function [lbl1,lbl2]=ImgClassification2(im1,im2,mask,mask3,points,s,twop)
%mask ��ɫ����ͼ
%mask3 �ظ�����mask
%points ����յ�
%s
% lbl1=[];
%%%%%%�Ľ�
im11=im1;
im22=im2;
%
im11=testn(im11);
im22=testn(im22);
% figure;imshow(im11);
% figure;imshow(im22);
kk=rgb2gray(im1)&rgb2gray(im2);

hih=0.6;
lol=0.5;


p1=imgaussfilt(double(rgb2gray(im11)),hih);
p2=imgaussfilt(double(rgb2gray(im11)),lol);
p3=p2-p1;

p1=imgaussfilt(double(rgb2gray(im22)),hih);
p2=imgaussfilt(double(rgb2gray(im22)),lol);
p4=p2-p1;


p5=p4-p3;
p5(p5<0)=0;
p5(p5>1)=1;
p5=p5.*kk;
figure;imshow(p5);
%%%%%%%%%%%
lbl2=[];

mask2=rgb2gray(mask);
mask2(mask2>0)=1;
%     mask2=bwareaopen(mask2,4);
mask2=bwareaopen(mask2,2);

[gr1,~]=imgradient(rgb2gray(im1));
gr1=mat2gray(gr1);
[gr2,~]=imgradient(rgb2gray(im2));
gr2=mat2gray(gr2);


d=abs(gr1-gr2)+mask2+(1-double(mask3));
d(d>1)=1;
% figure;imshow(d);
%8.30 �Ľ�
[~, line_data1, ~, ~, linesInfo] = LineSegmentDetector( rgb2gray(im1), 0.4, 0.6, 22.5, 0.7, 1024, 255 );
[~, line_data2, ~, ~, linesInfo] = LineSegmentDetector( rgb2gray(im2), 0.4, 0.6, 22.5, 0.7, 1024, 255 );
% line_data1=dete_line(im1);
% line_data2=dete_line(im2);
pd=abs(gr1-gr2)+abs(line_data1-line_data2)+mask2+(1-double(mask3));
pd=p5+abs(line_data1-line_data2)+mask2+(1-double(mask3));
figure;imshow(abs(line_data1-line_data2));
pd(pd>1)=1;
d=pd;
pdd=pd;
figure;imshow(d);
%%%%%%%

%%%%%%% �Ľ�
di=d;
pd=d(:);
sp=sort(pd);
tol=0.0001;
[sp,rsp]=uniquetol(sp,tol);
ok=0;
left=1;
right=numel(rsp);
mid=0;
flag=0;
while right-left~=1
    mid=fix((right-left)/2+left);
    di=d;
    di(di>sp(mid))=2;
    di(di<=sp(mid))=3;
    di=di-2;
    di(twop)=1;
    Dt=bwconncomp(di);
    flag=0;
    for j=1:Dt.NumObjects
        if ismember(twop,Dt.PixelIdxList{j})==[1;1]
            flag=1;
            break;
        end
    end
    if flag==1
        right=mid;
    else
        left=mid;
    end
end
ok=right;
if sp(ok)<1
d(d>sp(ok))=d(d>sp(ok))+1;
d(d>1)=1;
end
figure;imshow(d);
%%%%%%%%%%%%%%%%
%%%%%�Ľ�2
di=d;
di(di>sp(ok))=2;
di(di<=sp(ok))=3;
di=di-2;
di(twop)=1;
Dt=bwconncomp(di);
flag=0;
for j=1:Dt.NumObjects
    if ismember(twop,Dt.PixelIdxList{j})==[1;1]
        flag=j;
        break;
    end
end
if flag~=0
did=ones(size(d));
didz=zeros(size(d));
% did(Dt.PixelIdxList{flag})=0;
did(Dt.PixelIdxList{flag})=d(Dt.PixelIdxList{flag});
didz(Dt.PixelIdxList{flag})=d(Dt.PixelIdxList{flag});
if sp(ok)~=1
    d=did;
end
end
figure;imshow(d);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



[x1,y1]=find(points(:,:,1)==1);
x1 = x1(ceil(size(x1,1)/2));
y1 = y1(ceil(size(y1,1)/2));
[x2,y2]=find(points(:,:,2)==1);
x2 = x2(ceil(size(x2,1)/2));
y2 = y2(ceil(size(y2,1)/2));

lbl1=dp(d,[x1,y1],[x2,y2],im1,im2);
se=cat(3,d,d,d);
se(:,:,1)=se(:,:,1)+lbl1*255;
figure;
imshow(se);




return;

end