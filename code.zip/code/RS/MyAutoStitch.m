%% AutoStitch
function reg_imgs=MyAutoStitch(imgs)
    %lpm_method
    load_lpm;
    reg_imgs={};
    load_lpm
    
    I=imgs{1};
    if ndims(I)==3
        grayImage=rgb2gray(I);
    end
    
    %SUFT��������ȡ����
    metric_threshold = 200;
    num_octaves = 3;
    num_scale_levels = 4;
    %SURF
    points=detectSURFFeatures(grayImage, 'MetricThreshold', metric_threshold, 'NumOctaves',...
            num_octaves, 'NumScaleLevels', num_scale_levels);
    [features,points]=extractFeatures(grayImage,points);
    % %SIFT
    % [points,features]=vl_sift(single(grayImage),'PeakThresh', 0,'edgethresh',500);
    
    numImages=numel(imgs);
    tforms(numImages)=projective2d(eye(3));
    imageSize=zeros(numImages,2);
    imageSize(1,:)=size(grayImage);
    
    for N=2:numImages
        preFeatures=features;
        prePoints=points;
        I=imgs{N};
        if ndims(I)==3
            grayImage=rgb2gray(I);
        end
        imageSize(N,:)=size(grayImage);

        %SURF
        points=detectSURFFeatures(grayImage, 'MetricThreshold', metric_threshold, 'NumOctaves',...
            num_octaves, 'NumScaleLevels', num_scale_levels);
        [features,points]=extractFeatures(grayImage,points);
        pairs=matchFeatures(features,preFeatures,'Unique',true);
        matchedPoints=points(pairs(:,1),:);
        matchedPrePoints=prePoints(pairs(:,2),:);

    %     %SIFT
    %     [points,features]=vl_sift(single(grayImage),'PeakThresh', 0,'edgethresh',500);
    %     pairs = vl_ubcmatch(features,preFeatures);
    %     matchedPoints=points(1:2,pairs(1,:));
    %     matchedPrePoints=prePoints(1:2,pairs(2,:));
    %     matchedPoints=SURFPoints(matchedPoints');
    %     matchedPrePoints=SURFPoints(matchedPrePoints'); 
    %     pairs=pairs';

        %lpm
        pairs=lpm_method(matchedPoints,matchedPrePoints,pairs);
    %     %ransac
    %     [~,pairs]=ransac_method(matchedPoints,matchedPrePoints,pairs);

        %SURF
        matchedPoints=points(pairs(:,1),:);
        matchedPrePoints=prePoints(pairs(:,2),:);
        save matchedPrePoints;
        save matchedPoints
    %     %SIFT
    %     pairs=pairs';
    %     matchedPoints=points(1:2,pairs(1,:));
    %     matchedPrePoints=prePoints(1:2,pairs(2,:));
    %     matchedPoints=SURFPoints(matchedPoints');
    %     matchedPrePoints=SURFPoints(matchedPrePoints'); 

        tforms(N)=estimateGeometricTransform(matchedPoints,matchedPrePoints,...
            'projective','confidence',99.9,'MaxNumTrials',2000);
        tforms(N).T=tforms(N).T*tforms(N-1).T;
    end
    
    %���������
    for i = 1:numel(tforms)
        [xlim(i,:), ylim(i,:)] = outputLimits(tforms(i), [1 imageSize(i,2)], [1 imageSize(i,1)]);
    end

    avgXLim = mean(xlim, 2);

    [~, idx] = sort(avgXLim);

    centerIdx = floor((numel(tforms)+1)/2);

    centerImageIdx = idx(centerIdx);

    Tinv = invert(tforms(centerImageIdx));

    for i = 1:numel(tforms)
        tforms(i).T = tforms(i).T * Tinv.T;
    end

    for i = 1:numel(tforms)
        [xlim(i,:), ylim(i,:)] = outputLimits(tforms(i), [1 imageSize(i,2)], [1 imageSize(i,1)]);
    end
    save ('tforms.mat','tforms');
    maxImageSize = max(imageSize);
    % Find the minimum and maximum output limits
    %����ÿ�ű��κ��ͼ��Ĵ�С
    xMin = min([1; xlim(:)]);
    xMax = max([maxImageSize(2); xlim(:)]);

    yMin = min([1; ylim(:)]);
    yMax = max([maxImageSize(1); ylim(:)]);

    % Width and height of panorama.
    width  = round(xMax - xMin);
    height = round(yMax - yMin);
    %�ָ�

    % Initialize the "empty" panorama.
    if ndims(I) == 3
        panorama = zeros([height width 3], 'like', grayImage);
    else
        panorama = zeros([height width], 'like', grayImage);
    end

    % Create a 2-D spatial reference object defining the size of the panorama.
    xLimits = [xMin xMax];
    yLimits = [yMin yMax];
    panoramaView = imref2d([height width], xLimits, yLimits);
    
    %Binary_mask_method
    blender = vision.AlphaBlender('Operation', 'Binary mask', ...
        'MaskSource', 'Input port');%�ںϷ�ʽ
    for i=1:numImages
        I=imgs{i};
        %����
        warpedImage = imwarp(I, tforms(i), 'OutputView', panoramaView);
        mask_save = zeros(size(rgb2gray(warpedImage)));
        mask_save=double(xor((rgb2gray(warpedImage)),mask_save));
        imfolder1='F:\ͼ��ƴ��\1-�����ƴ�Ӻϼ�\reg_images';
        imp_path1=sprintf('%s\\p_%02d.png', imfolder1, i);
        imwrite(warpedImage, imp_path1) ;
        reg_imgs{i}=warpedImage;
        mask{i}=imwarp(true(size(I,1),size(I,2)),tforms(i),'OutputView',panoramaView);
        panorama=step(blender,panorama,warpedImage,mask{i});
    end
end