%%
function Img2=testn(Img1)
 
% ��ȡͼ��
% Img1 = imread('4.png');
Img=Img1;
% M = size(Img);
% if numel(M)>2
%     gray = rgb2gray(Img);
% else
%     gray = Img;
% end
 

%1075 1076  [500,500],300
%59 60 no testn
%705 707 [500,500],300


W = fspecial('gaussian',[500,500],300); 
Img(:,:,1) = imfilter(Img(:,:,1), W, 'replicate');
Img(:,:,2) = imfilter(Img(:,:,2), W, 'replicate');
Img(:,:,3) = imfilter(Img(:,:,3), W, 'replicate');
Img2(:,:,1)=Img1(:,:,1)-Img(:,:,1);
Img2(:,:,2)=Img1(:,:,2)-Img(:,:,2);
Img2(:,:,3)=Img1(:,:,3)-Img(:,:,3);
% figure;
% imshow(Img);
% figure;
% imshow(Img2);
end