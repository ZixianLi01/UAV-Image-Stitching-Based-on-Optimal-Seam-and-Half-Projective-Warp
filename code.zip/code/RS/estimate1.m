%%
function estimate1(seam,img1,img2)

%seam�Ƿ�����ϵĵ㣬Ϊһ��ͼƬ(��ֵͼ��)
%img1,img2�� ��׼�� ������ͼƬ

ssim_img1=img1.*uint8(seam);
ssim_img2=img2.*uint8(seam);
[mssim,ssim_map] = ssim_index(ssim_img1, ssim_img2);
ssim_map=ssim_map.*double(seam);
sumnum=sum(sum(ssim_map(ssim_map~=0)),2);
sumnum1=sum(sum(seam~=0),2);
ssim_value=sumnum/sumnum1;
E_patch=((1-ssim_map)/2).*double(seam);

%seam����һλ
seam_point=zeros(size(seam,1),size(seam,2)+1);
seam_point(:,2:size(seam_point,2))=seam;

point_img1=img1.*uint8(seam);
point_img2=img2.*uint8(seam);
point_left=double(point_img1)-double(point_img2);
left=point_left.*point_left;
left_value=left(:,:,1)+left(:,:,2)+left(:,:,3);
left_value=sqrt(left_value);

point_img1=img1.*uint8(seam_point(:,1:size(seam_point,2)-1));
point_img2=img2.*uint8(seam_point(:,1:size(seam_point,2)-1));
point_right=double(point_img1)-double(point_img2);
right=point_right.*point_right;
right_value=right(:,:,1)+right(:,:,2)+right(:,:,3);
right_value=sqrt(right_value);  

E_point=(left_value+right_value)/2;

times=100;
E_pi=times.*E_patch.*E_point;
% close all;
% figure;imshow(E_pi);

pi_sum=sum(sum(E_pi(E_pi~=0)),2);
pi_num=sum(sum(E_pi~=0),2);
E_pi_ave=pi_sum/pi_num
end