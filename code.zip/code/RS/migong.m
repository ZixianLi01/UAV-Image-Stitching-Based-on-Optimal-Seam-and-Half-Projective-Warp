%%
function q=migong(q,p1,p2)
    [m,n]=size(q);
    map=q;
    Travers=q;
    Traversed=[];
    Infect=q;
    Infected=[];
    Infected=[Infected;p1];
    Infect(p1(1),p1(2))=-1;
    Traversed=[Traversed;p1];
    while size(Infected,1)>0
        point=Infected(1,1:2);
        if point ==p2
            break;
        end
        Travers(point(1),point(2))=-1;
        Traversed=[Traversed;point];
        %left
        if point(2)-1>0 && Travers(point(1),point(2)-1)~=-1 && map(point(1),point(2)-1)~=0
            map(point(1),point(2)-1)=minval(map,[point(1),point(2)-1],Travers)+1;
            if Infect(point(1),point(2)-1)~=-1 && Travers(point(1),point(2)-1)~=-1
                Infected=[Infected;[point(1),point(2)-1]];
                Infect(point(1),point(2)-1)=-1;
            end
        end
         %left up
        if point(2)-1>0 && point(1)-1>0 && Travers(point(1)-1,point(2)-1)~=-1 && map(point(1)-1,point(2)-1)~=0
            map(point(1)-1,point(2)-1)=minval(map,[point(1)-1,point(2)-1],Travers)+1;
            if Infect(point(1)-1,point(2)-1)~=-1 && Travers(point(1)-1,point(2)-1)~=-1
                Infected=[Infected;[point(1)-1,point(2)-1]];
                Infect(point(1)-1,point(2)-1)=-1;
            end
        end
        %up
        if point(1)-1>0 && Travers(point(1)-1,point(2))~=-1 && map(point(1)-1,point(2))~=0
            map(point(1)-1,point(2))=minval(map,[point(1)-1,point(2)],Travers)+1;
            if Infect(point(1)-1,point(2))~=-1 && Travers(point(1)-1,point(2))~=-1
                Infected=[Infected;[point(1)-1,point(2)]];
                Infect(point(1)-1,point(2))=-1;
            end
        end
         %right up
        if point(2)+1<n+1 && point(1)-1>0 && Travers(point(1)-1,point(2)+1)~=-1 && map(point(1)-1,point(2)+1)~=0
            map(point(1)-1,point(2)+1)=minval(map,[point(1)-1,point(2)+1],Travers)+1;
            if Infect(point(1)-1,point(2)+1)~=-1 && Travers(point(1)-1,point(2)+1)~=-1
                Infected=[Infected;[point(1)-1,point(2)+1]];
                Infect(point(1)-1,point(2)+1)=-1;
            end
        end
        %right
        if point(2)+1<n+1 && Travers(point(1),point(2)+1)~=-1 && map(point(1),point(2)+1)~=0
            map(point(1),point(2)+1)=minval(map,[point(1),point(2)+1],Travers)+1;
            if Infect(point(1),point(2)+1)~=-1 && Travers(point(1),point(2)+1)~=-1
                Infected=[Infected;[point(1),point(2)+1]];
                Infect(point(1),point(2)+1)=-1;
            end
        end
         %right down
        if point(2)+1<n+1 && point(1)+1<m+1 && Travers(point(1)+1,point(2)+1)~=-1 && map(point(1)+1,point(2)+1)~=0
            map(point(1)+1,point(2)+1)=minval(map,[point(1)+1,point(2)+1],Travers)+1;
            if Infect(point(1)+1,point(2)+1)~=-1 && Travers(point(1)+1,point(2)+1)~=-1
                Infected=[Infected;[point(1)+1,point(2)+1]];
                Infect(point(1)+1,point(2)+1)=-1;
            end
        end
        %dowm
        if point(1)+1<m+1 && Travers(point(1)+1,point(2))~=-1 && map(point(1)+1,point(2))~=0
            map(point(1)+1,point(2))=minval(map,[point(1)+1,point(2)],Travers)+1;
            if Infect(point(1)+1,point(2))~=-1 && Travers(point(1)+1,point(2))~=-1
                Infected=[Infected;[point(1)+1,point(2)]];
                Infect(point(1)+1,point(2))=-1;
            end
        end
        %left down
        if point(2)-1>0 && point(1)+1<m+1 && Travers(point(1)+1,point(2)-1)~=-1 && map(point(1)+1,point(2)-1)~=0
            map(point(1)+1,point(2)-1)=minval(map,[point(1)+1,point(2)-1],Travers)+1;
            if Infect(point(1)+1,point(2)-1)~=-1 && Travers(point(1)+1,point(2)-1)~=-1
                Infected=[Infected;[point(1)+1,point(2)-1]];
                Infect(point(1)+1,point(2)-1)=-1;
            end
        end
        Infected(1,:)=[];
    end
    lp=map;
    map=getMap(map,p1,p2);
    q=map;

end

%%�򻯷����
function map=getMap(map,p1,p2)
    [m,n]=size(map);
    newmap=zeros(size(map));
    newmap(p2(1),p2(2))=map(p2(1),p2(2));
    point=p2;
    minnum=map(p1(1),p1(2));
    num=map(p2(1),p2(2));
    while num>minnum
        %left
        if point(2)-1>0 && map(point(1),point(2)-1)==num-1
            newmap(point(1),point(2)-1)=map(point(1),point(2)-1);
            point(1)=point(1);
            point(2)=point(2)-1;
            num=newmap(point(1),point(2));
            continue;
        end
        %left up
        if point(1)-1>0 && point(2)-1>0 && map(point(1)-1,point(2)-1)==num-1
            newmap(point(1)-1,point(2)-1)=map(point(1)-1,point(2)-1);
            point(1)=point(1)-1;
            point(2)=point(2)-1;
            num=newmap(point(1),point(2));
            continue;
        end
        %up
        if point(1)-1>0 && map(point(1)-1,point(2))==num-1
            newmap(point(1)-1,point(2))=map(point(1)-1,point(2));
            point(1)=point(1)-1;
            point(2)=point(2);
            num=newmap(point(1),point(2));
            continue;
        end
        %right up
        if point(1)-1>0 && point(2)+1<n+1 && map(point(1)-1,point(2)+1)==num-1
            newmap(point(1)-1,point(2)+1)=map(point(1)-1,point(2)+1);
            point(1)=point(1)-1;
            point(2)=point(2)+1;
            num=newmap(point(1),point(2));
            continue;
        end
        %right
        if point(2)+1<n+1 && map(point(1),point(2)+1)==num-1
            newmap(point(1),point(2)+1)=map(point(1),point(2)+1);
            point(1)=point(1);
            point(2)=point(2)+1;
            num=newmap(point(1),point(2));
            continue;
        end
        %right down
        if point(1)+1<m+1 && point(2)+1<n+1 && map(point(1)+1,point(2)+1)==num-1
            newmap(point(1)+1,point(2)+1)=map(point(1)+1,point(2)+1);
            point(1)=point(1)+1;
            point(2)=point(2)+1;
            num=newmap(point(1),point(2));
            continue;
        end
        %down
        if point(1)+1<m+1 && map(point(1)+1,point(2))==num-1
            newmap(point(1)+1,point(2))=map(point(1)+1,point(2));
            point(1)=point(1)+1;
            point(2)=point(2);
            num=newmap(point(1),point(2));
            continue;
        end
        %left down
        if point(1)+1<m+1 && point(2)-1>0 && map(point(1)+1,point(2)-1)==num-1
            newmap(point(1)+1,point(2)-1)=map(point(1)+1,point(2)-1);
            point(1)=point(1)+1;
            point(2)=point(2)-1;
            num=newmap(point(1),point(2));
            continue;
        end
    end
    map=newmap;
end

function val=minval(map,Thepoint,Travers)
    [m,n]=size(map);
    vals=[];
    %left
    if Thepoint(2)-1>0 && Travers(Thepoint(1),Thepoint(2)-1)==-1
        vals=[vals,map(Thepoint(1),Thepoint(2)-1)];
    end
    % left up
    if Thepoint(2)-1>0 && Thepoint(1)-1>0 && Travers(Thepoint(1)-1,Thepoint(2)-1)==-1
        vals=[vals,map(Thepoint(1)-1,Thepoint(2)-1)];
    end
    %up
    if Thepoint(1)-1>0 && Travers(Thepoint(1)-1,Thepoint(2))==-1
        vals=[vals,map(Thepoint(1)-1,Thepoint(2))];
    end
    %right up
    if Thepoint(2)+1<n+1 && Thepoint(1)-1>0 && Travers(Thepoint(1)-1,Thepoint(2)+1)==-1
        vals=[vals,map(Thepoint(1)-1,Thepoint(2)+1)];
    end
    %right
    if Thepoint(2)+1<n+1 && Travers(Thepoint(1),Thepoint(2)+1)==-1
        vals=[vals,map(Thepoint(1),Thepoint(2)+1)];
    end
    %right down 
    if Thepoint(2)+1<n+1 && Thepoint(1)+1<m+1 && Travers(Thepoint(1)+1,Thepoint(2)+1)==-1
        vals=[vals,map(Thepoint(1)+1,Thepoint(2)+1)];
    end
    %down
    if Thepoint(1)+1<m+1 && Travers(Thepoint(1)+1,Thepoint(2))==-1
        vals=[vals,map(Thepoint(1)+1,Thepoint(2))];
    end
    %left down
    if Thepoint(2)-1>0 && Thepoint(1)+1<m+1 && Travers(Thepoint(1)+1,Thepoint(2)-1)==-1
        vals=[vals,map(Thepoint(1)+1,Thepoint(2)-1)];
    end
    vals(find(vals==0))=[];
    val=min(vals);
end

%�ж��Ƿ������  ������Ϊ0��δ������Ϊ1
function flag=findIn(point,Traversed)
    flag=1;
    for i=1:size(Traversed,1)
        if point==Traversed(i,1:2)
            flag=0;
            return;
        end
    end
end