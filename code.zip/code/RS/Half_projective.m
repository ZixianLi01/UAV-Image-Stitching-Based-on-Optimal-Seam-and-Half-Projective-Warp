% close all
% clear
% clc
run('vlfeat-0.9.21/toolbox/vl_setup');

img_n = 2; % The number of input images
in_name = cell(img_n,1);
in_name{1} = [image_fold,'\','pk11.png'];
in_name{2} = [image_fold,'\','p2.jpg'];  
lpl=double(imread(in_name{1}));
lpl2=double(imread(in_name{2}));
mask1=rgb2gray(lpl)&rgb2gray(lpl);
mask2=rgb2gray(lpl2)&rgb2gray(lpl2);
mask1=double(mask1)*255;
mask2=double(mask2)*255;
lpl(:,:,1)=mask1;
lpl2(:,:,1)=mask2;
lpl2=imresize(lpl2,[684 1024]);
imwrite(lpl,[image_fold,'\','mask1.png']);
imwrite(lpl2,[image_fold,'\','mask2.png']);
lpl2=double(imread(in_name{2}));
lpl2=imresize(lpl2,[684 1024]);
imwrite(uint8(lpl2),[image_fold,'\','mask2.png']);
edge_list = [1,2]; % Each row represents an image pair to be aligned.
% In this example, there is only one pair (image 1 and image 2).
ref = 2; % the index of the reference image
tar = 1; % the index of the target image. Our warp is constructed from the homgraphy that maps from ref to tar
warp_type = 'ours';
zeroR_ON = 1; % whether we restrict the similarity warp in our warp to be no rotation (zeroR_ON=1) or not (zeroR_ON=0)
SPHP_stitching(in_name, edge_list, ref, tar, warp_type, zeroR_ON,image_fold,fold); % run stitching
fprintf('Half_projective Done!');
