%%
%% Read images
% close all
% clear
addpath('linedete');
addpath('LSDֱ�߶μ���㷨');
addpath('������');

fold1=sprintf('%s\\pk01.png',fold);
fold2=sprintf('%s\\pk02.png',fold);
imgpath1=[image_fold,'\','p_01.png'];
imgpath2=[image_fold,'\','p_02.png'];
img1 = imread(imgpath1);
img2 = imread(imgpath2);

%% Find start point and end point
mask1=double(rgb2gray(img1)&rgb2gray(img1));
mask2=double(rgb2gray(img2)&rgb2gray(img2));
[points, im1, im2, repeat_mask, Dx, Dy, twop]=FindStEnPintsAndRegion(img1, img2, mask1, mask2);
% points  ͼ���ص����ֵ������յ�
% im1 & im2 ͼ��1ͼ��2�Ķ�Ӧ�ص�����
% mask ͼ���ص���������
% Dx & Dy ͼ���ص����ֲü�����XY����
% twop ͼ���ص����������յ�����
%% Seam Estimation in Repeat Region
seamcut=SeamEstimation(im1,im2,points,twop);
% seamcut �����

%% Seam Cut
seam=zeros(size(mask1));
seam(Dy+1:size(seamcut,1)+Dy,Dx+1:size(seamcut,2)+Dx)=seamcut;

seam=bwmorph(seam,'diag');
seam=double(imfill(uint8(seam)));

img1_mask=mask1-seam;
cc1=bwlabel(img1_mask);

img2_mask=mask2-seam;
cc2=bwlabel(img2_mask);

m1=double(img1_mask-img2_mask).*cc1;
m2=double(img2_mask-img1_mask).*cc2;

u1=unique(m1);
u2=unique(m2);

img1_mask=zeros(size(img1_mask));
img2_mask=zeros(size(img2_mask));

img1_mask(cc1==u1(end))=1;
img2_mask(cc2==u2(end))=1;

img1_mask=img1_mask+seam;
img2_mask=img2_mask+seam;

% figure;imshow(img1_mask);
% figure;imshow(img2_mask);
% img1_mask & img2_mask is the region of two original images by seam cut
imwrite(im1,'im1.png','png','Alpha',repeat_mask);
imwrite(im2,'im2.png','png','Alpha',repeat_mask);
%% Show resaults
imwrite(img1,fold1,'png','Alpha',img1_mask);
imwrite(img2,fold2,'png','Alpha',img2_mask);

sysorder = sprintf('enblend --output=%s\\mosaic_blend.png', fold) ;
for i = 1:2
    sysorder = sprintf('%s %s\\pk%02d.png',sysorder, fold, i) ;
end
sysorder = sprintf('%s --gpu', sysorder) ;

system(sysorder) ;
pan=imread('mosaic_blend.png');
figure;
imshow(pan);


imwrite(pan,'seam_mosaic_blend.jpg');
imwrite(pan,'seam_mosaic_blend.png');
pan(:,:,1)=pan(:,:,1)+uint8(seam)*255;
figure;
imshow(pan);

%% Save cuted image

lpl=imread('pk01.png');
mks=double(rgb2gray(lpl)&rgb2gray(lpl));
x=max(mks);
[a,I]=max(x);
x(1,1:I)=1;      
[a,I2]=min(x);   
if I2==1         
    I2=size(mks,2);
end

x=max(mks');
[a,I3]=max(x);
lck=lpl(:,:,1);
x(1,1:I3)=1;
[a,I4]=min(x);     
if I4==1
   I4=size(mks,1);
end
lms(:,:,1)=lpl(I3:I4,I:I2,1);
lms(:,:,2)=lpl(I3:I4,I:I2,2);
lms(:,:,3)=lpl(I3:I4,I:I2,3);
imwrite(lms,[image_fold,'\','pk11.jpg']);
imwrite(lms,[image_fold,'\','pk11.png']);
lcs(:,:,1)=img1(I3:I4,I:I2,1);
lcs(:,:,2)=img1(I3:I4,I:I2,2);
lcs(:,:,3)=img1(I3:I4,I:I2,3);
imwrite(lcs,[image_fold,'\','pk11ts.jpg']);
imwrite(lcs,[image_fold,'\','pk11ts.png']);
seammask=seam(I3:I4,I:I2);
imwrite(double(seammask),[image_fold,'\','seam.png']);

seampoints1=zeros(size(mask1));
seampoints1(Dy+1:size(seamcut,1)+Dy,Dx+1:size(seamcut,2)+Dx)=points(:,:,1);
seampoints2=zeros(size(mask1));
seampoints2(Dy+1:size(seamcut,1)+Dy,Dx+1:size(seamcut,2)+Dx)=points(:,:,2);

seampoints1=seampoints1(I3:I4,I:I2);
seampoints2=seampoints2(I3:I4,I:I2);
imwrite(seampoints1,[image_fold,'\','seampoints1.png']);
imwrite(seampoints2,[image_fold,'\','seampoints2.png']);

fprintf('Seam_method Done!');
