%%
function seamcut=SeamEstimation(im1,im2,points,twop)

%%
% Color Diff
repeat_mask=double(rgb2gray(im1)&rgb2gray(im2));
ColDif=abs(im2double(im1)-im2double(im2)); %两图相减
m=min(ColDif,[],3);  % 求三维矩阵每个位置最小�?
s=((sum(ColDif,3)-m)/2);  %三维加起来减去最小�?再除�?
ColDif=ColDif.*repmat(double(repeat_mask),[1,1,3]);  %去除非重复部�?
a=(mean(max(ColDif,[],1))+mean(min(ColDif,[],1)))/2; %每列�?��值和�?��值相加除2
b=(mean(max(ColDif,[],2))+mean(min(ColDif,[],2)))/2; %每行�?��值和�?��值相加除2
max_=(a+b)/2;  %重复区域每个图层颜色均�?
color_diff=[];
color_diff(:,:,1)= ColDif(:,:,1) - max_(1,1,1); %重复区域减去图层颜色均�?
color_diff(:,:,2)= ColDif(:,:,2) - max_(1,1,2);
color_diff(:,:,3)= ColDif(:,:,3) - max_(1,1,3);
color_diff(color_diff<0)=0;   %颜色差异
color_diff=rgb2gray(color_diff);
color_diff(color_diff>1)=1;
color_diff=bwareaopen(color_diff,2);
% figure;imshow(color_diff);
%%
% Structure Diff  Use Gauss
im11=im1;
im22=im2;
im11=testn(im11);
im22=testn(im22);

high_fre=0.6;
low_fre=0.5;

img1_high=imgaussfilt(double(rgb2gray(im11)),high_fre);
img1_low=imgaussfilt(double(rgb2gray(im11)),low_fre);
img1_diff=img1_high-img1_low;

img2_high=imgaussfilt(double(rgb2gray(im22)),high_fre);
img2_low=imgaussfilt(double(rgb2gray(im22)),low_fre);
img2_diff=img2_high-img2_low;

struct_diff=img2_diff-img1_diff;
struct_diff=abs(struct_diff);
% max_diff=max(struct_diff,[],'all');
max_diff=max(max(struct_diff));
struct_diff=struct_diff/max_diff;
% figure;imshow(struct_diff);
%%
% Struct Diff Use Sobel
[gr1,~]=imgradient(rgb2gray(im1));
gr1=mat2gray(gr1);
[gr2,~]=imgradient(rgb2gray(im2));
gr2=mat2gray(gr2);
struct_sobel_diff=abs(gr1-gr2);


%%
% Line Diff
[~, line_data1, ~, ~, linesInfo] = LineSegmentDetector( rgb2gray(im1), 0.4, 0.6, 22.5, 0.7, 1024, 255 );
[~, line_data2, ~, ~, linesInfo] = LineSegmentDetector( rgb2gray(im2), 0.4, 0.6, 22.5, 0.7, 1024, 255 );
line_diff=abs(line_data1-line_data2);
% figure;imshow(line_diff);

%%
%Energy function d
d=color_diff+struct_diff+line_diff+(1-double(repeat_mask));
d(d>1)=1;
% figure;imshow(d);
% d=imfill(d);
%%
% limit Energy function
di=d;
pd=d(:);
sp=sort(pd);
tol=0.0001;
[sp,rsp]=uniquetol(sp,tol);
ok=0;
left=1;
right=numel(rsp);
mid=0;
flag=0;
while right-left~=1
    mid=fix((right-left)/2+left);
    di=d;
    di(di>sp(mid))=2;
    di(di<=sp(mid))=3;
    di=di-2;
    di(twop)=1;
    Dt=bwconncomp(di);
    flag=0;
    for j=1:Dt.NumObjects
        if ismember(twop,Dt.PixelIdxList{j})==[1;1]
            flag=1;
            break;
        end
    end
    if flag==1
        right=mid;
    else
        left=mid;
    end
end
ok=right;
if sp(ok)<1
d(d>sp(ok))=d(d>sp(ok))+1;
d(d>1)=1;
end
% figure;imshow(d);

% only save the region of start point and end point
di=d;
di(di>sp(ok))=2;
di(di<=sp(ok))=3;
di=di-2;
di(twop)=1;
Dt=bwconncomp(di);
flag=0;
for j=1:Dt.NumObjects
    if ismember(twop,Dt.PixelIdxList{j})==[1;1]
        flag=j;
        break;
    end
end
if flag~=0
did=ones(size(d));
didz=zeros(size(d));
% did(Dt.PixelIdxList{flag})=0;
did(Dt.PixelIdxList{flag})=d(Dt.PixelIdxList{flag});
didz(Dt.PixelIdxList{flag})=d(Dt.PixelIdxList{flag});
if sp(ok)~=1
    d=did;
end
end
figure;imshow(d);
%%
% determine start point and end point location
[x1,y1]=find(points(:,:,1)==1);
x1 = x1(ceil(size(x1,1)/2));
y1 = y1(ceil(size(y1,1)/2));
[x2,y2]=find(points(:,:,2)==1);
x2 = x2(ceil(size(x2,1)/2));
y2 = y2(ceil(size(y2,1)/2));
%%
% search seam Use dp
seamcut=dp(d,[x1,y1],[x2,y2],im1,im2);
% seamcut=dp2(d,[x1,y1],[x2,y2],im1,im2);
se=cat(3,d,d,d);
se(:,:,1)=se(:,:,1)+seamcut*255;
figure;imshow(se);
end