%%
%Load LPM
run('vlfeat-0.9.21/toolbox/vl_setup');
addpath('transforms');