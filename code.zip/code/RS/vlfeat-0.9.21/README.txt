VLFeat 0.9.21 binary package can be downloaded from:
http://www.vlfeat.org/