%%
function C = my_multi_blending_1(A, B,maskA,maskB)
    A_size = size(A);
    B_size = size(B);
    C_size= size(B);
    kernel=fspecial('gaussian',[5 5],1);
    %obtain the Gauss Pyramid
    G_A0 = A;
    G_A1 = conv2(double(G_A0),kernel,'same');
    G_A1 = G_A1(2:2:size(G_A1,1),2:2:size(G_A1,2));
    G_A2 = conv2(double(G_A1),kernel,'same');
    G_A2 = G_A2(2:2:size(G_A2,1),2:2:size(G_A2,2));
    G_A3 = conv2(double(G_A2),kernel,'same');
    G_A3 = G_A3(2:2:size(G_A3,1),2:2:size(G_A3,2));
    G_A4 = conv2(double(G_A3),kernel,'same');
    G_A4 = G_A4(2:2:size(G_A4,1),2:2:size(G_A4,2));
    G_A5 = conv2(double(G_A4),kernel,'same');
    G_A5 = G_A5(2:2:size(G_A5,1),2:2:size(G_A5,2));

    G_B0 = B;
    G_B1 = conv2(double(G_B0),kernel,'same');
    G_B1 = G_B1(2:2:size(G_B1,1),2:2:size(G_B1,2));
    G_B2 = conv2(double(G_B1),kernel,'same');
    G_B2 = G_B2(2:2:size(G_B2,1),2:2:size(G_B2,2));
    G_B3 = conv2(double(G_B2),kernel,'same');
    G_B3 = G_B3(2:2:size(G_B3,1),2:2:size(G_B3,2));
    G_B4 = conv2(double(G_B3),kernel,'same');
    G_B4 = G_B4(2:2:size(G_B4,1),2:2:size(G_B4,2));
    G_B5 = conv2(double(G_B4),kernel,'same');
    G_B5 = G_B5(2:2:size(G_B5,1),2:2:size(G_B5,2));

    %get Laplacian Pyramid
    L_A0 = double(G_A0)-imresize(G_A1,size(G_A0));
    L_A1 = double(G_A1)-imresize(G_A2,size(G_A1));
    L_A2 = double(G_A2)-imresize(G_A3,size(G_A2));
    L_A3 = double(G_A3)-imresize(G_A4,size(G_A3));
    L_A4 = double(G_A4)-imresize(G_A5,size(G_A4));
    L_A5 = double(G_A5);

    L_B0 = double(G_B0)-imresize(G_B1,size(G_B0));
    L_B1 = double(G_B1)-imresize(G_B2,size(G_B1));
    L_B2 = double(G_B2)-imresize(G_B3,size(G_B2));
    L_B3 = double(G_B3)-imresize(G_B4,size(G_B3));
    L_B4 = double(G_B4)-imresize(G_B5,size(G_B4));
    L_B5 = double(G_B5);
    
    size0=size(L_A0);
    L_A1=imresize(L_A1,size0);
    L_A2=imresize(L_A2,size0);
    L_A3=imresize(L_A3,size0);
    L_A4=imresize(L_A4,size0);
    L_A5=imresize(L_A5,size0);
    
    L_B1=imresize(L_B1,size0);
    L_B2=imresize(L_B2,size0);
    L_B3=imresize(L_B3,size0);
    L_B4=imresize(L_B4,size0);
    L_B5=imresize(L_B5,size0);
    
    maskA=double(maskA);
    maskB=double(maskB);
    
    L_C0 = L_A0 .* maskA + L_B0 .* maskB;
    L_C1 = L_A1 .* maskA + L_B1 .* maskB;
    L_C2 = L_A2 .* maskA + L_B2 .* maskB;
    L_C3 = L_A3 .* maskA + L_B3 .* maskB;
    L_C4 = L_A4 .* maskA + L_B4 .* maskB;
    L_C5 = L_A5 .* maskA + L_B5 .* maskB;
    
    C=L_C0+L_C1+L_C2+L_C3+L_C4+L_C5;
    %obtain the output
%     L_C0 = L_A0 .* (1-mask0) + L_B0 .* mask0;
%     L_C1 = L_A1 .* (1-mask1) + L_B1 .* mask1;
%     L_C2 = L_A2 .* (1-mask2) + L_B2 .* mask2;
%     L_C3 = L_A3 .* (1-mask3) + L_B3 .* mask3;
%     L_C4 = L_A4 .* (1-mask4) + L_B4 .* mask4;
%     L_C5 = L_A5 .* (1-mask5) + L_B5 .* mask5;
%     size0=size(L_A0);
% %     C = L_C0+imresize(L_C1,size0)+imresize(L_C2,size0)+imresize(L_C3,size0)+imresize(L_C4,size0)+imresize(L_C5,size0);
%     C=double(A).*(1-mask0) + double(B) .* mask0;
%     figure(1);
%     imshow(A);
% %     figure(2);
%     imshow(B);
% %     figure(3);
%     m=double(A|B);
%     C=C.*(double(A|B));
%     imshow(uint8(C));
    
    
end
