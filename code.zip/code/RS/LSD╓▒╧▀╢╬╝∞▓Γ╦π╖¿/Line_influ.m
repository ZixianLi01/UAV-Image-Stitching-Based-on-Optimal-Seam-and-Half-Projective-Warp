function img_out= Line_influ(img)
syms X SIGMA C;
C=0;
SIGMA=1;
se=strel('disk',3);
[i,j]=size(img);
img_out=zeros(i,j);
img=img>0;
X=1;
img_out(find(img))=gaussmf(X,[SIGMA C]);
img2=imdilate(img,se);
border_1=img2-img;
X=1;
img_out(find(border_1))=gaussmf(X,[SIGMA C]);
img3=imdilate(img2,se);
border_1=img3-img2;
X=2;
img_out(find(border_1))=gaussmf(X,[SIGMA C]);
img4=imdilate(img3,se);
border_1=img4-img3;
X=3;
img_out(find(border_1))=gaussmf(X,[SIGMA C]);
img5=imdilate(img4,se);
border_1=img5-img4;
X=4;
img_out(find(border_1))=gaussmf(X,[SIGMA C]);
 img_gauss_u8=im2uint8(img_out);
   img_out=imadjust(img_gauss_u8);
end
        