close all;clear;
%% qu1
load C:\Users\Minions\Desktop\627\ourdata1.mat;
ourdata1=kp;
load C:\Users\Minions\Desktop\627\QEISEdata1.mat;
QEISEdata1=kp;
load C:\Users\Minions\Desktop\627\PSCdata1.mat;
PSCdata1=kp;
load C:\Users\Minions\Desktop\627\FARSEdata1.mat;
FARSEdata1=kp;

dengju1=floor(linspace(1,numel(ourdata1),500));
y1=ourdata1(dengju1);
dengju2=floor(linspace(1,numel(QEISEdata1),500));
y2=QEISEdata1(dengju2);
dengju3=floor(linspace(1,numel(PSCdata1),500));
y3=PSCdata1(dengju3);
dengju4=floor(linspace(1,numel(FARSEdata1),500));
y4=FARSEdata1(dengju4);
y=[y1,y2,y3,y4];
x=1:500;
figure;
plot(x,y1,'r',x,y2,'b',x,y3,'g',x,y4,'k')
title('Case 1'); 
xlabel('N'); 
ylabel('Q');
% figure;
% plot(x,y2)
% figure;
% plot(x,y1)
legend('OURS','QEISE','PSC','FARSE') 
grid on

%% qu2
load C:\Users\Minions\Desktop\627\ourdata2.mat;
ourdata1=kp;
load C:\Users\Minions\Desktop\627\QEISEdata2.mat;
QEISEdata1=kp;
load C:\Users\Minions\Desktop\627\PSCdata2.mat;
PSCdata1=kp;
load C:\Users\Minions\Desktop\627\FARSEdata2.mat;
FARSEdata1=kp;

dengju1=floor(linspace(1,numel(ourdata1),500));
y1=ourdata1(dengju1);
dengju2=floor(linspace(1,numel(QEISEdata1),500));
y2=QEISEdata1(dengju2);
dengju3=floor(linspace(1,numel(PSCdata1),500));
y3=PSCdata1(dengju3);
dengju4=floor(linspace(1,numel(FARSEdata1),500));
y4=FARSEdata1(dengju4);
y=[y1,y2,y3,y4];
x=1:500;
figure;
plot(x,y1,'r',x,y2,'b',x,y3,'g',x,y4,'k')
title('Case 2'); 
xlabel('N'); 
ylabel('Q');
% figure;
% plot(x,y2)
% figure;
% plot(x,y1)
legend('OURS','QEISE','PSC','FARSE') 
grid on
%% qu3
load C:\Users\Minions\Desktop\627\ourdata3.mat;
ourdata1=kp;
load C:\Users\Minions\Desktop\627\QEISEdata3.mat;
QEISEdata1=kp;
load C:\Users\Minions\Desktop\627\PSCdata3.mat;
PSCdata1=kp;
load C:\Users\Minions\Desktop\627\FARSEdata3.mat;
FARSEdata1=kp;

dengju1=floor(linspace(1,numel(ourdata1),500));
y1=ourdata1(dengju1);
dengju2=floor(linspace(1,numel(QEISEdata1),500));
y2=QEISEdata1(dengju2);
dengju3=floor(linspace(1,numel(PSCdata1),500));
y3=PSCdata1(dengju3);
dengju4=floor(linspace(1,numel(FARSEdata1),500));
y4=FARSEdata1(dengju4);
y=[y1,y2,y3,y4];
x=1:500;
figure;
plot(x,y1,'r',x,y2,'b',x,y3,'g',x,y4,'k')
title('Case 3'); 
xlabel('N'); 
ylabel('Q');
% figure;
% plot(x,y2)
% figure;
% plot(x,y1)
legend('OURS','QEISE','PSC','FARSE') 
grid on
%% qu4
load C:\Users\Minions\Desktop\627\ourdata4.mat;
ourdata1=kp;
load C:\Users\Minions\Desktop\627\QEISEdata4.mat;
QEISEdata1=kp;
load C:\Users\Minions\Desktop\627\PSCdata4.mat;
PSCdata1=kp;
load C:\Users\Minions\Desktop\627\FARSEdata4.mat;
FARSEdata1=kp;

dengju1=floor(linspace(1,numel(ourdata1),500));
y1=ourdata1(dengju1);
dengju2=floor(linspace(1,numel(QEISEdata1),500));
y2=QEISEdata1(dengju2);
dengju3=floor(linspace(1,numel(PSCdata1),500));
y3=PSCdata1(dengju3);
dengju4=floor(linspace(1,numel(FARSEdata1),500));
y4=FARSEdata1(dengju4);
y=[y1,y2,y3,y4];
x=1:500;
figure;
plot(x,y1,'r',x,y2,'b',x,y3,'g',x,y4,'k')
title('Case 4'); 
xlabel('N'); 
ylabel('Q');
% figure;
% plot(x,y2)
% figure;
% plot(x,y1)
legend('OURS','QEISE','PSC','FARSE') 
grid on